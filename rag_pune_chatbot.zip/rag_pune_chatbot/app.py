from chatbot import build_chatbot

if __name__ == "__main__":
    print("🌄 Welcome to the Pune Travel Assistant Chatbot!")
    # replace model path with whatever model you pick
    model_path = "models/mistral-7b-instruct-v0.1.Q5_K_M.gguf"
    bot = build_chatbot(model_path)

    while True:
        user_input = input("\nAsk about Pune (or type 'exit'): ")
        if user_input.lower() in ("exit", "quit"):
            print("Goodbye!")
            break
        resp = bot.invoke(user_input)
        print("\n🤖", resp)
