#from langchain.document_loaders import PyMuPDFLoader, WebBaseLoader
from langchain_community.document_loaders import PyMuPDFLoader, WebBaseLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
#from langchain.vectorstores import FAISS
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings

#from langchain.embeddings import HuggingFaceEmbeddings
import os

def load_documents():
    docs = []
    # load PDFs if available
    pdf_dir = "data/pune_guides_pdfs"
    for fname in os.listdir(pdf_dir):
        if fname.lower().endswith(".pdf"):
            path = os.path.join(pdf_dir, fname)
            loader = PyMuPDFLoader(path)
            docs.extend(loader.load())

    # load web pages from known Pune related URLs
    urls = [
        "https://maharashtratourism.gov.in/districts/pune/",
        "https://incredibleindia.gov.in/en/maharashtra/pune"
    ]
    web_loader = WebBaseLoader(urls)
    docs.extend(web_loader.load())

    return docs

def split_documents(documents):
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    return splitter.split_documents(documents)

def store_embeddings(chunks, index_path="embeddings/faiss_index"):
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    db = FAISS.from_documents(chunks, embeddings)
    db.save_local(index_path)

if __name__ == "__main__":
    docs = load_documents()
    chunks = split_documents(docs)
    store_embeddings(chunks)
    print("✅ Pune documents ingested & embeddings stored.")
