from langchain_community.vectorstores import FAISS
#from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.llms import LlamaCpp  # or whatever local LLM you pick
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate

def load_vectorstore(index_path="embeddings/faiss_index"):
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    return FAISS.load_local(index_path, embeddings,allow_dangerous_deserialization=True)

def load_llm(model_path):
    return LlamaCpp(
        model_path=model_path,
        temperature=0.7,
        max_tokens=512,
        top_p=0.95,
        n_ctx=2048,
        verbose=False
    )

def build_chatbot(model_path):
    vectorstore = load_vectorstore()
    llm = load_llm(model_path)

    prompt_template = """
    You are a helpful assistant for tourists visiting Pune.
    Use the context below to answer the user's question as accurately as possible.

    Context:
    {context}

    Question: {question}
    Helpful Answer:
    """

    prompt = PromptTemplate(
        template=prompt_template,
        input_variables=["context", "question"]
    )

    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=vectorstore.as_retriever(),
        chain_type_kwargs={"prompt": prompt}
    )

    return qa_chain
