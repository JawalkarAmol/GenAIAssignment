1. Install pre requisites
 pip install requirements.txt
2.donwload llm and put under /models folder
e.g.mistral-7b-instruct-v0.1.Q5_K_M.gguf
3.run ingest.py - this will ingest pune data 
4.run app.py  - this will run chatbot in cli where prompts can be given to ask about Pune city/travel guide.